﻿Imports System.IO

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' SaveFileDialog setup
        SaveFileDialog1.Filter = "WaaScript files (*.waa)|*.waa"
        SaveFileDialog1.DefaultExt = "waa"
        SaveFileDialog1.AddExtension = True

        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim filePath As String = SaveFileDialog1.FileName
            ' Write the RichTextBox contents to the file
            File.WriteAllText(filePath, RichTextBox1.Text)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' OpenFileDialog setup
        OpenFileDialog1.Filter = "WaaScript files (*.waa)|*.waa"
        OpenFileDialog1.DefaultExt = "waa"

        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim filePath As String = OpenFileDialog1.FileName
            ' Read file contents and load into RichTextBox
            Dim contents As String = File.ReadAllText(filePath)
            RichTextBox1.Text = contents
        End If
    End Sub
End Class