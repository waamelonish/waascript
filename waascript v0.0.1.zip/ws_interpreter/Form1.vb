﻿Imports System
Imports System.IO
Imports System.Windows.Forms
Imports System.Linq   ' Needed for Skip()
Imports System.Collections.Generic
Imports System.Reflection.Metadata

Public Class Form1
    ' Track where to add spawned controls
    Private currentForm As Form

    ' Variable store
    Private variables As New Dictionary(Of String, Integer)
    ' bool storing
    Private boolTable As New Dictionary(Of String, Boolean)
    ' int.
    Private intTable As New Dictionary(Of String, Integer)
    ' string..how was this not implemented BEFORE bool?
    Private stringTable As New Dictionary(Of String, String)



    ' Loop state
    Private insideLoop As Boolean = False
    Private loopCondition As String = ""
    Private loopStartIndex As Integer = 0

    ' If state
    Private insideIf As Boolean = False
    Private ifConditionResult As Boolean = False

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' By default, target this form
        currentForm = Me

        ' Get command line arguments
        Dim args As String() = Environment.GetCommandLineArgs()

        If args.Length > 1 Then
            Dim filePath As String = args(1)
            If File.Exists(filePath) Then
                RichTextBox1.Text = File.ReadAllText(filePath)
            Else
                RichTextBox1.Text = "File not found: " & filePath
            End If
        End If

        ' --- Scan phase ---
        Dim commands() As String = RichTextBox1.Text.Split({";"}, StringSplitOptions.RemoveEmptyEntries)

        RichTextBox1.AppendText(Environment.NewLine & "[DEBUG] Scan complete. Found " & commands.Length & " command(s)." & Environment.NewLine)

        For i As Integer = 0 To commands.Length - 1
            Dim cmd As String = commands(i).Trim()
            RichTextBox1.AppendText("[DEBUG] Parsing command: " & cmd & Environment.NewLine)

            ' --- Variable assignment ---
            If cmd.Contains("=") AndAlso Not cmd.StartsWith("if") AndAlso Not cmd.StartsWith("while") Then
                Dim parts() As String = cmd.Split({"="}, StringSplitOptions.RemoveEmptyEntries)
                If parts.Length = 2 Then
                    Dim varName As String = parts(0).Trim()
                    Dim valueStr As String = parts(1).Trim()
                    Dim valueInt As Integer
                    Integer.TryParse(valueStr, valueInt)
                    variables(varName) = valueInt
                    RichTextBox1.AppendText("[DEBUG] Variable " & varName & " set to " & valueInt & Environment.NewLine)
                End If
            End If

            ' --- If statement ---
            If cmd.StartsWith("if ") AndAlso cmd.Contains(" then") Then
                Dim condition As String = cmd.Substring(3, cmd.Length - 7).Trim()
                Dim parts() As String = condition.Split({" "}, StringSplitOptions.RemoveEmptyEntries)
                If parts.Length = 3 Then
                    Dim leftVal As Integer = If(variables.ContainsKey(parts(0)), variables(parts(0)), 0)
                    Dim rightInt As Integer
                    Integer.TryParse(parts(2), rightInt)
                    Select Case parts(1)
                        Case "<" : ifConditionResult = (leftVal < rightInt)
                        Case ">" : ifConditionResult = (leftVal > rightInt)
                        Case "=" : ifConditionResult = (leftVal = rightInt)
                    End Select
                    insideIf = True
                    RichTextBox1.AppendText("[DEBUG] If condition evaluated: " & ifConditionResult & Environment.NewLine)
                End If
            End If

            If cmd = "end" AndAlso insideIf Then
                insideIf = False
                RichTextBox1.AppendText("[DEBUG] End of if block" & Environment.NewLine)
            End If

            ' --- While loop start ---
            If cmd.StartsWith("while ") AndAlso cmd.Contains(" do") Then
                loopCondition = cmd.Substring(6, cmd.Length - 8).Trim()
                loopStartIndex = i
                insideLoop = True
                RichTextBox1.AppendText("[DEBUG] While loop started" & Environment.NewLine)
            End If

            ' --- While loop end ---
            If cmd = "end" AndAlso insideLoop Then
                ' Re‑evaluate condition
                Dim parts() As String = loopCondition.Split({" "}, StringSplitOptions.RemoveEmptyEntries)
                Dim leftVal As Integer = If(variables.ContainsKey(parts(0)), variables(parts(0)), 0)
                Dim rightInt As Integer
                Integer.TryParse(parts(2), rightInt)

                Dim result As Boolean = False
                Select Case parts(1)
                    Case "<" : result = (leftVal < rightInt)
                    Case ">" : result = (leftVal > rightInt)
                    Case "=" : result = (leftVal = rightInt)
                End Select

                If result Then
                    ' Jump back to loop start
                    i = loopStartIndex - 1
                    RichTextBox1.AppendText("[DEBUG] While loop repeating" & Environment.NewLine)
                Else
                    insideLoop = False
                    RichTextBox1.AppendText("[DEBUG] While loop ended" & Environment.NewLine)
                End If
            End If

            If cmd = "end" AndAlso insideLoop Then
                ' Re‑evaluate condition
                Dim parts() As String = loopCondition.Split({" "}, StringSplitOptions.RemoveEmptyEntries)
                Dim leftVal As Integer = If(variables.ContainsKey(parts(0)), variables(parts(0)), 0)
                Dim rightInt As Integer
                Integer.TryParse(parts(2), rightInt)
                Dim result As Boolean = False
                Select Case parts(1)
                    Case "<" : result = (leftVal < rightInt)
                    Case ">" : result = (leftVal > rightInt)
                    Case "=" : result = (leftVal = rightInt)
                End Select

                If result Then
                    i = loopStartIndex - 1 ' jump back
                Else
                    insideLoop = False
                    RichTextBox1.AppendText("[DEBUG] While loop ended" & Environment.NewLine)
                End If
            End If

            ' --- windowNew(width height title...) ---
            If cmd.StartsWith("windowNew(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring("windowNew(".Length, cmd.Length - "windowNew(".Length - 1)
                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                Dim w As Integer = 400
                Dim h As Integer = 300
                Dim title As String = "Window"

                If parts.Length >= 2 Then
                    Integer.TryParse(parts(0), w)
                    Integer.TryParse(parts(1), h)
                    RichTextBox1.AppendText("[DEBUG] Parsed size: " & w & "x" & h & Environment.NewLine)
                End If

                If parts.Length > 2 Then
                    title = String.Join(" ", parts.Skip(2))
                    RichTextBox1.AppendText("[DEBUG] Parsed title: " & title & Environment.NewLine)
                End If

                Dim f As New Form() With {
        .Text = title,
        .Width = w,
        .Height = h,
        .StartPosition = FormStartPosition.Manual
    }

                f.Show()                ' show without blocking
                currentForm = f         ' set as target for spawned controls
                RichTextBox1.AppendText("[DEBUG] Window created and shown. Target set to new window." & Environment.NewLine)
            End If

            ' --- print(text) ---
            If cmd.StartsWith("print(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring(6, cmd.Length - 7)
                RichTextBox1.AppendText(inner & Environment.NewLine)
                RichTextBox1.AppendText("[DEBUG] Printed: " & inner & Environment.NewLine)
            End If

            ' --- spawnRichTextBox(x y w h text...) ---
            If cmd.StartsWith("spawnRichTextBox(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring("spawnRichTextBox(".Length, cmd.Length - "spawnRichTextBox(".Length - 1)
                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                Dim x As Integer = 20
                Dim y As Integer = 200
                Dim w As Integer = 200
                Dim h As Integer = 100
                Dim text As String = "[DEBUG] New RichTextBox spawned"

                If parts.Length >= 4 Then
                    Integer.TryParse(parts(0), x)
                    Integer.TryParse(parts(1), y)
                    Integer.TryParse(parts(2), w)
                    Integer.TryParse(parts(3), h)
                End If

                If parts.Length > 4 Then
                    text = String.Join(" ", parts.Skip(4))
                End If

                Dim rtb As New RichTextBox() With {
        .Text = text,
        .Width = w,
        .Height = h,
        .Left = x,
        .Top = y,
        .Name = text   ' assign a stable name
    }

                Dim target As Control = If(currentForm IsNot Nothing, currentForm, Me)
                target.Controls.Add(rtb)

                RichTextBox1.AppendText("[DEBUG] RichTextBox created at (" & x & "," & y & ") size " & w & "x" & h &
                            " name: " & rtb.Name & " on target: " & target.FindForm().Text & Environment.NewLine)
            End If
            ' --- spawnLabel(x y text...) ---
            If cmd.StartsWith("spawnLabel(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring("spawnLabel(".Length, cmd.Length - "spawnLabel(".Length - 1)
                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                Dim x As Integer = 20
                Dim y As Integer = 20
                Dim text As String = "Label"

                If parts.Length >= 2 Then
                    Integer.TryParse(parts(0), x)
                    Integer.TryParse(parts(1), y)
                End If
                If parts.Length > 2 Then
                    text = String.Join(" ", parts.Skip(2))
                End If

                Dim lbl As New Label() With {
        .Text = text,
        .Left = x,
        .Top = y,
        .AutoSize = True,
        .Name = text   ' assign a stable name
    }

                Dim target As Control = If(currentForm IsNot Nothing, currentForm, Me)
                target.Controls.Add(lbl)

                RichTextBox1.AppendText("[DEBUG] Label created at (" & x & "," & y & ") text: " & text &
                            " name: " & lbl.Name & " on target: " & target.FindForm().Text & Environment.NewLine)
            End If
            ' --- spawnButton(x y w h text...) ---
            If cmd.StartsWith("spawnButton(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring("spawnButton(".Length, cmd.Length - "spawnButton(".Length - 1)
                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                Dim x As Integer = 20
                Dim y As Integer = 50
                Dim w As Integer = 100
                Dim h As Integer = 30
                Dim text As String = "Button"

                If parts.Length >= 4 Then
                    Integer.TryParse(parts(0), x)
                    Integer.TryParse(parts(1), y)
                    Integer.TryParse(parts(2), w)
                    Integer.TryParse(parts(3), h)
                End If
                If parts.Length > 4 Then
                    text = String.Join(" ", parts.Skip(4))
                End If

                Dim btn As New Button() With {
        .Text = text,
        .Name = text,   ' assign a stable name for later lookup
        .Left = x,
        .Top = y,
        .Width = w,
        .Height = h
    }

                Dim target As Control = If(currentForm IsNot Nothing, currentForm, Me)
                target.Controls.Add(btn)

                RichTextBox1.AppendText("[DEBUG] Button created at (" & x & "," & y & ") size " & w & "x" & h &
                            " name: " & btn.Name & " text: " & text &
                            " on target: " & target.FindForm().Text & Environment.NewLine)
            End If
            ' --- setProperty(controlName property value) ---
            If cmd.StartsWith("setProperty(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring("setProperty(".Length, cmd.Length - "setProperty(".Length - 1)
                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                If parts.Length >= 3 Then
                    Dim controlName As String = parts(0)
                    Dim propName As String = parts(1)
                    Dim propValue As String = String.Join(" ", parts.Skip(2))

                    ' Find control by its Name (set when spawning)
                    Dim target As Control = currentForm.Controls.OfType(Of Control)().
            FirstOrDefault(Function(c) c.Name = controlName)

                    If target IsNot Nothing Then
                        Select Case propName.ToLower()
                            Case "text"
                                target.Text = propValue
                            Case "width"
                                Dim w As Integer
                                If Integer.TryParse(propValue, w) Then target.Width = w
                            Case "height"
                                Dim h As Integer
                                If Integer.TryParse(propValue, h) Then target.Height = h
                            Case "left"
                                Dim x As Integer
                                If Integer.TryParse(propValue, x) Then target.Left = x
                            Case "top"
                                Dim y As Integer
                                If Integer.TryParse(propValue, y) Then target.Top = y
                        End Select

                        RichTextBox1.AppendText("[DEBUG] Property " & propName & " of " & controlName &
                                    " set to " & propValue & Environment.NewLine)
                    Else
                        RichTextBox1.AppendText("[DEBUG] Control " & controlName & " not found" & Environment.NewLine)
                    End If
                End If
            End If
            If cmd.StartsWith("newBool(") AndAlso cmd.EndsWith(")") Then
                ' Strip off "newBool(" and ")"
                Dim inner As String = cmd.Substring("newBool(".Length, cmd.Length - "newBool(".Length - 1)
                inner = inner.TrimEnd(")"c)

                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                If parts.Length = 2 Then
                    Dim valueStr As String = parts(0).ToLower()
                    Dim name As String = parts(1)

                    Dim value As Boolean = False
                    If valueStr = "true" Then value = True
                    If valueStr = "false" Then value = False

                    boolTable(name) = value   ' store in dictionary
                    RichTextBox1.AppendText("[DEBUG] Bool " & name & " = " & value.ToString() & Environment.NewLine)
                End If
            End If
            If cmd.StartsWith("newInt(") AndAlso cmd.EndsWith(")") Then
                ' Strip off "newInt(" and ")"
                Dim inner As String = cmd.Substring("newInt(".Length, cmd.Length - "newInt(".Length - 1)
                inner = inner.TrimEnd(")"c)

                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                If parts.Length = 2 Then
                    Dim valueStr As String = parts(0)
                    Dim name As String = parts(1)

                    Dim value As Integer
                    If Integer.TryParse(valueStr, value) Then
                        intTable(name) = value
                        RichTextBox1.AppendText("[DEBUG] Int " & name & " = " & value.ToString() & Environment.NewLine)
                    Else
                        RichTextBox1.AppendText("[ERROR] Invalid int value: " & valueStr & Environment.NewLine)
                    End If
                End If
            End If
            ' Add a new handler for variables
            If cmd.StartsWith("setVar(") AndAlso cmd.EndsWith(")") Then
                Dim inner As String = cmd.Substring("setVar(".Length, cmd.Length - "setVar(".Length - 1)
                inner = inner.TrimEnd(")"c)

                Dim parts() As String = inner.Split({" "}, StringSplitOptions.RemoveEmptyEntries)

                If parts.Length = 2 Then
                    Dim name As String = parts(0)
                    Dim valueStr As String = parts(1)

                    ' Try int first
                    Dim intVal As Integer
                    If Integer.TryParse(valueStr, intVal) Then
                        intTable(name) = intVal
                        RichTextBox1.AppendText("[DEBUG] Int " & name & " = " & intVal & Environment.NewLine)
                    ElseIf valueStr.ToLower() = "true" OrElse valueStr.ToLower() = "false" Then
                        boolTable(name) = (valueStr.ToLower() = "true")
                        RichTextBox1.AppendText("[DEBUG] Bool " & name & " = " & boolTable(name).ToString() & Environment.NewLine)
                    Else
                        stringTable(name) = valueStr
                        RichTextBox1.AppendText("[DEBUG] String " & name & " = " & valueStr & Environment.NewLine)
                    End If
                End If
            End If
            RichTextBox1.AppendText("[DEBUG] invalid syntax! " & cmd)

        Next ' very big and chunky hardcoding
    End Sub
End Class